class Prioritizer:
    def score(self, task: dict) -> float:
        hint = (task.get("priority_hint") or "").lower()
        if "high" in hint: return 0.9
        if "medium" in hint: return 0.6
        return 0.4
