from src.extractor import Extractor
from src.prioritizer import Prioritizer
from src.planner import Planner
from src.executor import Executor
from src.llm_interface import LLM
from src.calendar_api_mock import CalendarAPIMock

class Manager:
    def __init__(self):
        self.llm = LLM(provider="mock")
        self.extractor = Extractor(self.llm)
        self.prioritizer = Prioritizer()
        self.calendar = CalendarAPIMock()
        self.planner = Planner(self.calendar)
        self.executor = Executor()

    def process_message(self, text, mid):
        task = self.extractor.extract(text, mid)
        score = self.prioritizer.score(task)
        event = self.planner.schedule(task)
        email = self.executor.draft_email(task)
        return {"task": task, "priority": score, "event": event, "email": email}
