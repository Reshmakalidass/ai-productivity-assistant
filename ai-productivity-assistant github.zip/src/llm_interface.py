import json
from typing import Any

class LLM:
    def __init__(self, provider="mock"):
        self.provider = provider

    def generate(self, prompt: str) -> str:
        if self.provider == "mock":
            return json.dumps({
                "title": "Follow up with client",
                "description": "Send follow up email",
                "duration_minutes": 30,
                "priority_hint": "medium",
                "due_date": None
            })
        raise NotImplementedError()
