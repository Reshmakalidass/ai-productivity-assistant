from datetime import datetime, timedelta

class Planner:
    def __init__(self, calendar_api):
        self.calendar = calendar_api

    def schedule(self, task: dict):
        duration = task.get("duration_minutes", 30)
        today = datetime.now().date()
        start = datetime.combine(today, datetime.min.time()) + timedelta(hours=9)
        end = start + timedelta(minutes=duration)
        return self.calendar.create_event(task["title"], start.isoformat(), end.isoformat(), task.get("description"))
