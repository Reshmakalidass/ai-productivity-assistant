class CalendarAPIMock:
    def __init__(self):
        self.events = []

    def create_event(self, title, start, end, description):
        e = {"id": len(self.events)+1, "title": title, "start": start, "end": end, "description": description}
        self.events.append(e)
        return e
