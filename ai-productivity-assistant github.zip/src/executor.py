class Executor:
    def draft_email(self, task):
        return f"Subject: {task['title']}\n\nReminder: {task['description']}"
