import json
from src.llm_interface import LLM

class Extractor:
    def __init__(self, llm: LLM):
        self.llm = llm

    def extract(self, text: str, source_id: str):
        prompt = f"Extract a task from this message in JSON: {text}"
        resp = self.llm.generate(prompt)
        try:
            data = json.loads(resp)
        except:
            data = {
                "title": text[:40],
                "description": text,
                "duration_minutes": 20,
                "priority_hint": "low",
            }
        data["source_id"] = source_id
        return data
