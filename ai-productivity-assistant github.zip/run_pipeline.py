import pandas as pd
from src.manager import Manager

mgr = Manager()
df = pd.read_csv("data/mock_messages.csv")

for _, r in df.iterrows():
    print(mgr.process_message(r["text"], r["id"]))
