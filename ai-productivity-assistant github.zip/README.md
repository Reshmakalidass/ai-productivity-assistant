# AI Productivity Assistant
Run with:
```
pip install -r requirements.txt
python run_pipeline.py
```